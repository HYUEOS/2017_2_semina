/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.android.fragments;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class ArticleFragment extends Fragment {
    final static String ARG_POSITION = "position";
    int mCurrentPosition = -1;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, 
        Bundle savedInstanceState) {

        // 만약 액티비티가 재생성될때(화면 전환이 될 때), 현재 액티비티의 데이터가 재생성과 같이 사자리기 때문에 이전 상태의 액티비티 데이터를 미리 저장해서 복구시켜야합니다.
        // 이러한 액티비티 재생성 과정은 특히 태블릿과 같은 큰 기기의 세로화면에서 가로화면으로 전환될때 발생하므로,
        // 가로화면에서 2개로 화면을 분할하는 경우에 데이터를 미리 저장하고 저장된 데이터를 복구하는 과정은 필수적입니다.
        // 만약 savedInstanceState가 null이 아니면 복구해야할 데이터가 있다는 의미입니다.
        if (savedInstanceState != null) {
            // 복구할 데이터가 있다면 mCurrentPosition 에 그 값을 받아와 저장합니다.
            mCurrentPosition = savedInstanceState.getInt(ARG_POSITION);
        }

        // 해당 프레그먼트 안에 R.layout.article_view 레이아웃을 합칩니다.
        return inflater.inflate(R.layout.article_view, container, false);
    }

    @Override
    public void onStart() {
        super.onStart();

        // onStart 메소드에서는 액티비티에서 프레그먼트로 전달될 인자가 있는지 조사해봅니다.
        // onStart 메소드는 이미 메인 레이아웃에 프레그먼트가 결합된 상태에서 발생되는 메소드이므로,
        // 기사문을 설정해주는 함수를 안전하게 호출하는데 적합합니다.
        Bundle args = getArguments();
        if (args != null) {
            // 만약 화면 방향의 변경 등으로 인해 저장된 데이터가 있다면 저장된 데이터를 이용해 기사문을 설정합니다.
            updateArticleView(args.getInt(ARG_POSITION));
        } else if (mCurrentPosition != -1) {
            // 화면변경등과 같은 이벤트가 없이 onCreateView 메소드에서 정상적으로 넘어온 경우엔 mCurrentPosition 번째 fragment 로 기사문을 설정합니다.
            updateArticleView(mCurrentPosition);
        }
    }

    public void updateArticleView(int position) {
        TextView article = (TextView) getActivity().findViewById(R.id.article);
        article.setText(Ipsum.Articles[position]);
        mCurrentPosition = position;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        // 액티비티가 재생성될 때(주로 가로 / 세로가 변경될때)를 대비해 현재 기사문이 몇 번째인지를 저장합니다.
        outState.putInt(ARG_POSITION, mCurrentPosition);
    }
}