/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.android.fragments;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class HeadlinesFragment extends ListFragment {
    OnHeadlineSelectedListener mCallback;

    // 메인 액티비티는 반드시 OnHeadlineSelectedListener 인터페이스를 구현해서 현재 Fragment 가 메인 액티비티로 정보를 전달할 수 있도록 해야합니다.
    public interface OnHeadlineSelectedListener {
        /** 이 리스너 인터페이스는 리스트의 항목이 선택되었을때 현재 Fragment 가 호출하게 될 메소드입니다. */
        public void onArticleSelected(int position);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 기기간 호환성을 위해, 허니콤보다 오래된 기기에 대해서는 다른 리스트 아이템 레이아웃을 사용해야합니다.
        int layout = Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB ?
                android.R.layout.simple_list_item_activated_1 : android.R.layout.simple_list_item_1;

        // lpsum 헤드라인 배열을 이용해 Array Adapter 를 만들어 리스트뷰에 적용합니다.
        setListAdapter(new ArrayAdapter<String>(getActivity(), layout, Ipsum.Headlines));
    }

    @Override
    public void onStart() {
        super.onStart();

        // 2분할 레이아웃에서는 리스트뷰가 선택된 리스트 항목을 강조하게끔 설정합니다.
        // (onStart 에서 굳이 이런 작업을 하는 이유는 리스트뷰가 이 시점에서 사용가능하기 때문입니다.)
        if (getFragmentManager().findFragmentById(R.id.article_fragment) != null) {
            getListView().setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        // 이 코드는 메인 액티비티가 콜백 인터페이스를 구현했는지 확실한지 검사하는 코드로서 구현하지 않았다면 exception 을 나게끔 합니다.
        try {
            mCallback = (OnHeadlineSelectedListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnHeadlineSelectedListener");
        }
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        // 메인 액티비티에게 이 항목이 선택되었다고 알려줍니다.
        mCallback.onArticleSelected(position);
        
        // 2분할 레이아웃에서도 선택된 항목이 강조되도록 설정합니다.
        getListView().setItemChecked(position, true);
    }
}