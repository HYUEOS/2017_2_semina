/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.android.fragments;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;

public class MainActivity extends FragmentActivity 
        implements HeadlinesFragment.OnHeadlineSelectedListener {

    /** 액티비티가 처음 생성되었을 때 호출되는 메소드. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.news_articles);

        // 액티비티가 프레그먼트 컨테이너인 FrameLayout 을 사용하는 중인지를 확인한다. 만약 사용중이라면, 첫번째 프레그먼트를 반드시 추가해야한다.
        if (findViewById(R.id.fragment_container) != null) {

            // 하지만, 만약 이전상태로부터 복구되는 상황이라면, 우리는 아무것도 할 필요가 없으므로 return을 하여 onCreate 함수를 나가거나 fragment 를 겹치도록 만들 수 있다.
            if (savedInstanceState != null) {
                return;
            }

            // 처음 화면에 보여질 Fragment 를 만든다.
            HeadlinesFragment firstFragment = new HeadlinesFragment();

            // 만약 액티비티가 어떤 인텐트로부터 특별한 명령과 함께 시작되었다면, intent 로부터 전달받은 값을 프레그먼트에 인자로 전달해야한다.
            firstFragment.setArguments(getIntent().getExtras());

            // 'fragment_container' FrameLayout 을 프레그먼트에 추가한다.
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.fragment_container, firstFragment).commit();
        }
    }

    public void onArticleSelected(int position) {
        // 사용자로부터 Headlines Fragment 에 있는 헤드라인이 선택된 경우

        // 액티비티 레이아웃으로부터 Article Fragment 를 가져온다.
        ArticleFragment articleFrag = (ArticleFragment)
                getSupportFragmentManager().findFragmentById(R.id.article_fragment);

        if (articleFrag != null) {
            // 만약 Article Fragment 이 사용가능하다면, 2분할 레이아웃을 사용할 수 있다.

            // Article Fragment 의 함수를 호출해서 내용물을 변경한다.
            articleFrag.updateArticleView(position);

        } else {
            // 만약 Article Fragment 이 사용불가하다면, 2분할 레이아웃을 사용할 수 없으므로 Fragment 를 교체해야 한다.

            // Article Fragment 를 만들고 선택된 기사에 대한 정보를 전달한다.
            ArticleFragment newFragment = new ArticleFragment();
            Bundle args = new Bundle();
            args.putInt(ArticleFragment.ARG_POSITION, position);
            newFragment.setArguments(args);
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

            // 프레그먼트 컨테이너안에 있는 것을 현재 프레그먼트와 교체한다.
            // 그리고 사용자가 다시 되돌아올 수 있도록 Back Stack 에 트랜잭션을 추가한다.
            transaction.replace(R.id.fragment_container, newFragment);
            transaction.addToBackStack(null);

            // 트랜잭션을 commit 한다.
            transaction.commit();
        }
    }
}