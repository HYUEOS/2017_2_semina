package com.example.nam_yeong_u.selector;

import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class MainActivity extends AppCompatActivity {
    Button checked, enable, focused, pressed, selected;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checked = (CheckBox)findViewById(R.id.main_btn_checked);
        enable = (Button) findViewById(R.id.main_btn_enable);
        focused = (Button) findViewById(R.id.main_btn_focused);
        pressed = (Button) findViewById(R.id.main_btn_pressed);
        selected = (Button) findViewById(R.id.main_btn_selected);



        enable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enable.setEnabled(false);
            }
        });

        focused.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                focused.setFocusable(false);
            }
        });

        pressed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pressed.setPressed(false);
            }
        });
    }
}
