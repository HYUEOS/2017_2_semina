package com.example.sihwan.viewpagerexample;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by cmtyx on 2017-01-21.
 * Commented by Sihwan on 2017-09-27.
 */

public class Item extends PagerAdapter {
    Context context;
    ArrayList<String> text;


    /*
        생성자입니다.
        //arg0 : 이 Adapter 가 사용되는 Activity 의 정보(context)를 받아옵니다.
        //arg1 : 각 페이지에 들어갈 text 데이터를 받아옵니다.
     */
    Item(Context context, ArrayList<String> text) {
        this.context = context;
        this.text = text;
    }

    /*
        RecyclerView 의 Adapter 의 getItemCount() 와 동일한 기능을 하는 함수입니다.
        아이템 개수를 지정하고 리턴합니다.
     */
    @Override
    public int getCount() {
        return text.size();
    }

    /*
        함수 이름처럼 아이템을 동적으로 객체화해주는(생성해주는) 함수입니다.
        참고 : instance == 객체. instantiate == 객체화.

        arg0: xml 상에서 ViewPager 의 영역에 해당하는 부분을 객체화한 것입니다.
        arg1: 목록 번호를 뜻합니다. 당연한 말이지만 0 부터 시작합니다.
     */
    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        /*
            inflater 를 통해 ViewPager 의 각 목록에 들어갈 아이템들을 동적으로 즉각 생성해주는 코드입니다.
            ViewPager 의 각각의 아이템 형식은 보통 fragment 이거나 이 코드처럼 즉각 생성한 layout 이 됩니다.
        */
        LayoutInflater inflater = LayoutInflater.from(context);
        // pager_item.xml 을 가지고 layout 객체를 생성하는 코드입니다.
        LinearLayout layout = (LinearLayout) inflater.inflate(R.layout.pager_item, container, false);


        TextView textView = (TextView)layout.findViewById(R.id.text);
        textView.setText(text.get(position));

        /*
            addView() 함수는 ViewGroup 클래스에 속한 함수로, 인자로 들어간 layout 을 container 에 추가해줍니다.
         */
        container.addView(layout, 0);
        return layout;
    }

    /*
        함수 이름처럼 아이템을 제거합니다.

        arg0: instantiateItem 의 container 와 같습니다. xml 상에서 ViewPager 의 영역에 해당하는 부분을 객체화한 것입니다.
        arg1: instantiateItem 의 position 과 같습니다. 목록 번호를 뜻합니다.
        arg2: 해당하는 목록번호에 들어가 있는 item 을 뜻합니다. (즉, instantiateItem 에서 return 된 객체)
     */
    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout) object);
    }


    /*
        함수 이름처럼
        참고 : is... 형식의 함수는 true or false 여부를 결정하는 boolean 을 return 하는 함수 이름을 지을 때 쓰는 convention 입니다.

        여기저기 찾아본 결과, instantiateItem 에서 return 된 object 를 사용하고 있는건지 체크해준다고 합니다.
        Android Developer 사이트에 들어가보면 알겠지만, 설명이 그냥 없는거나 마찬가지였습니다...
        항상 필요한 함수라고 하니 그냥 씁시다...
     */
    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == (View)object;
    }
}