package com.example.sihwan.viewpagerexample;

import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ViewPager pager;
    ArrayList<String> eng;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 데이터
        eng = new ArrayList<>();
        eng.add("Hello");
        eng.add("world");
        eng.add("good");

        pager = (ViewPager)findViewById(R.id.viewpager);    // xml에 만든 ViewPager 객체화해주기
        Item mPagerAdapter = new Item(this,eng);    // adapter 생성
        pager.setAdapter(mPagerAdapter);    // adapter 연결
    }
}
