package com.example.sihwan.viewpagerwithfragment;

import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private ViewPager mViewPager;
    private MyPagerAdapter mPagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button mBtnFirst, mBtnSecond, mBtnThird;

        mViewPager = (ViewPager)findViewById(R.id.vp);
        mPagerAdapter = new MyPagerAdapter(getSupportFragmentManager());
        mBtnFirst = (Button)findViewById(R.id.btnFirst);
        mBtnSecond = (Button)findViewById(R.id.btnSecond);
        mBtnThird = (Button)findViewById(R.id.btnThird);

        mPagerAdapter.addFragment(new PagerFragment(MainActivity.this, 0));
        mPagerAdapter.addFragment(new PagerFragment(MainActivity.this, 1));
        mPagerAdapter.addFragment(new PagerFragment(MainActivity.this, 2));

        mViewPager.setAdapter(mPagerAdapter);

        mBtnFirst.setText("첫탭");
        mBtnSecond.setText("둘탭");
        mBtnThird.setText("셋탭");

        mBtnFirst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mViewPager.setCurrentItem(0);
            }
        });

        mBtnSecond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mViewPager.setCurrentItem(1);
            }
        });

        mBtnThird.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mViewPager.setCurrentItem(2);
            }
        });
    }
}
