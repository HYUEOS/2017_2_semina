package com.example.sihwan.viewpagerwithfragment;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * Created by sihwan on 2017. 9. 28..
 */

public class PagerFragment extends Fragment {

    private Context mContext;
    private int mTab;
    private View mView;
    private TextView mTvText;

    public PagerFragment(Context context, int tab){
        mContext = context;
        mTab = tab;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_main, null);
        mTvText = mView.findViewById(R.id.tvText);

        switch(mTab) {
            case 0:
                mTvText.setText("첫번째 페이지");
                break;
            case 1:
                mTvText.setText("두번째 페이지");
                break;
            case 2:
                mTvText.setText("세번째 페이지");
                break;
            default:
                break;
        }

        return mView;
    }
}
