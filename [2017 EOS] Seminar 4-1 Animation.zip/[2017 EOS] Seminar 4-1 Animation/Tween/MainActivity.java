package com.geulock.animationtest;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;



public class MainActivity extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnAlpha = (Button) findViewById(R.id.alpha);
        Button btnRotate = (Button) findViewById(R.id.rotate);
        Button btnScale = (Button) findViewById(R.id.scale);
        Button btnTranslate = (Button) findViewById(R.id.translate);
        Button btnSet = (Button) findViewById(R.id.set);

        final Animation animAlpha = AnimationUtils.loadAnimation(this,R.anim.alpha);
        final Animation animRotate = AnimationUtils.loadAnimation(this,R.anim.rotate);
        final Animation animScale = AnimationUtils.loadAnimation(this,R.anim.scale);
        final Animation animTranslate = AnimationUtils.loadAnimation(this,R.anim.translate);
        final Animation animSet = AnimationUtils.loadAnimation(this,R.anim.set);


        btnAlpha.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                v.startAnimation(animAlpha);
            }
        });

        btnRotate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                v.startAnimation(animRotate);
            }
        });

        btnScale.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                v.startAnimation(animScale);
            }
        });

        btnTranslate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                v.startAnimation(animTranslate);
            }
        });

        btnSet.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                v.startAnimation(animSet);
            }
        });
    }
}
