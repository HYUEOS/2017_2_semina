package com.eos.lsy010375.threadloading;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class LoadingActivity extends AppCompatActivity {
    private Thread splashThread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading);
        splashThread = new Thread() {
            @Override
            public void run() {
                try {
                    synchronized (this) {
                        // Wait given period of time
                        wait(5000);
                    }
                } catch (InterruptedException ex) {
                }
                finish();
                // Run next activity
                Intent intent = new Intent();
                intent.setClass(LoadingActivity.this,
                        MainActivity.class);
                startActivity(intent);
            }
        };
        splashThread.start();
    }
}
