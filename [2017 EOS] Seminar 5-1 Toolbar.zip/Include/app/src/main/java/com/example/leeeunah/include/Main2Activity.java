package com.example.leeeunah.include;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        View include2 = findViewById(R.id.top2);

        TextView txt3 = (TextView)include2.findViewById(R.id.txt1);
        TextView txt4 = (TextView)include2.findViewById(R.id.txt2);

    }
}
