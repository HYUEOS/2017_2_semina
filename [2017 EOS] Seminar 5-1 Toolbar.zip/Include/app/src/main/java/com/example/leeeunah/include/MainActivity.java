package com.example.leeeunah.include;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // id 중복 현상 때문에 상위 뷰계층에서 findVieById를 해줍니다.
        View include = findViewById(R.id.top);

        TextView txt1 = (TextView)include.findViewById(R.id.txt1);
        TextView txt2 = (TextView)include.findViewById(R.id.txt2);

        View include3 = findViewById(R.id.top3);

        TextView txt5 = (TextView)include3.findViewById(R.id.txt1);
        TextView txt6 = (TextView)include3.findViewById(R.id.txt2);
    }

    public void onClick(View view){
        switch (view.getId()) {
            case R.id.click_btn:
                Intent intent = new Intent(getApplicationContext(), Main2Activity.class);
                startActivity(intent);
                break;
        }
    }
}
