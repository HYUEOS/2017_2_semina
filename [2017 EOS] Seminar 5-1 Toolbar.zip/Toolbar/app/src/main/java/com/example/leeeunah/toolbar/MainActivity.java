package com.example.leeeunah.toolbar;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = (Toolbar) findViewById(R.id.toolbar);     // 툴바 선언
        setSupportActionBar(toolbar);                       // 액션바와 같이 세팅해줌

        // 툴바에 홈버튼 활성
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //getSupportActionBar().setHomeAsUpIndicator(/*원하는 이미지 경로 */);  // 툴바의 홈버튼 이미지를 변경해줌
    }

    @Override
    // xml에서 정의한 요소를 실제 뷰로 inflate 시켜준다.
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);

        return true;
    }

    @Override
    // 버튼 클릭할 때 나타내는 onClick함수와 비슷하다.
    // item을 클릭할 때 나타나는 액션을 설정해주면 된다.
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_setting:
                Toast.makeText(this, "설정 누름", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.menu_plus:
                Toast.makeText(this,"추가 누름", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.menu_search:
                Toast.makeText(this, "찾기 누름", Toast.LENGTH_SHORT).show();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }
}
